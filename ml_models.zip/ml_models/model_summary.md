# Machine Learning Model Summary

## Model Performance Comparison

| Model | Accuracy | Precision | Recall | F1 Score |
|-------|----------|-----------|--------|----------|
| random_forest | 0.9907 | 1.0000 | 0.9907 | 0.9953 |
| gradient_boosting | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| xgboost | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| logistic_regression | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| svm | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| neural_network | 1.0000 | 1.0000 | 1.0000 | 1.0000 |

Best model: **gradient_boosting** (F1: 1.0000)

## Feature Importance

| Feature | Importance |
|---------|------------|
| duration | 0.9227 |
| events_length | 0.0362 |
| login_attempts_length | 0.0179 |
| commands_length | 0.0169 |
| login_success | 0.0063 |
| login_attempts | 0.0000 |
| unique_commands | 0.0000 |
| command_count | 0.0000 |
| download_attempts | 0.0000 |
